'use strict'
;(() => {
  const Atelier = (window.ClankAtelier = window.ClankAtelier || {})
  Atelier.LocalePacks = Atelier.LocalePacks || {}
  Atelier.LocalePacks.en = {
    code: 'en',
    label: 'English',
    nativeLabel: 'English',
    messages: {}
  }
})()
