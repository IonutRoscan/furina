'use strict'

/*
    Essentials Router

    Essentials deliberately uses broad goals rather than exposing Furina's
    internal subsystem names. The advanced router remains completely intact.
*/
;(() => {
  const Atelier = window.ClankAtelier
  const State = Atelier.PanelState

  const STORAGE_KEY = 'furina-essentials-navigation-v1'

  const WORKSPACES = {
    home: {
      label: 'Home',
      icon: '⌂',
      title: 'Essentials',
      description: 'The fun parts of Furina, without the control room.',
      tools: []
    },
    customize: {
      label: 'Customize',
      icon: '◈',
      title: 'Make it yours',
      description:
        'Themes, backgrounds, and the visual controls most people actually need.',
      tools: []
    },
    roleplay: {
      label: 'Roleplay',
      icon: '◆',
      title: 'Help the story',
      description:
        'Remember important facts, guide the next reply, and keep the current scene grounded.',
      tools: []
    },
    immersion: {
      label: 'Immersion',
      icon: '✦',
      title: 'Set the mood',
      description: 'Atmosphere, music, stickers, and reading tools.',
      tools: []
    },
    more: {
      label: 'More',
      icon: '＋',
      title: 'More Furina',
      description:
        'Alternate interfaces, sharing, response styles, the Guidebook, and the full Atelier.',
      tools: []
    }
  }

  function sanitize(input) {
    const workspace = WORKSPACES[input?.workspace] ? input.workspace : 'home'

    return {
      workspace,
      loaded: true
    }
  }

  async function loadState() {
    if (State.essentialsNavigation?.loaded) {
      return
    }

    const stored = await Atelier.Storage.get(STORAGE_KEY, null)
    State.essentialsNavigation = sanitize(stored)
  }

  function saveState() {
    Atelier.Storage.set(STORAGE_KEY, {
      workspace: State.essentialsNavigation.workspace
    })
  }

  function getActive() {
    const workspace = WORKSPACES[State.essentialsNavigation.workspace]
      ? State.essentialsNavigation.workspace
      : 'home'

    return {
      workspace,
      tool: null,
      config: WORKSPACES[workspace]
    }
  }

  function navigate(workspace) {
    if (!WORKSPACES[workspace]) {
      return false
    }

    State.essentialsNavigation.workspace = workspace
    saveState()
    return true
  }

  function viewKey(workspace) {
    return `essentials:${workspace}`
  }

  function renderView(workspace) {
    const factory = Atelier.EssentialsWorkspaces

    switch (workspace) {
      case 'customize':
        return factory.createCustomize()
      case 'roleplay':
        return factory.createRoleplay()
      case 'immersion':
        return factory.createImmersion()
      case 'more':
        return factory.createMore()
      case 'home':
      default:
        return factory.createHome()
    }
  }

  function getBadge(workspace) {
    if (workspace === 'roleplay') {
      const continuity = Atelier.ContinuityManager?.settings?.entries || []
      const count = continuity.filter(
        item => item.enabled && !item.archived
      ).length
      return count
        ? {text: String(Math.min(count, 99)), label: `${count} active memories`}
        : null
    }

    if (workspace === 'immersion') {
      const active = Boolean(
        Atelier.AtmosphereManager?.settings?.enabled ||
        Atelier.AmbienceManager?.settings?.url ||
        Atelier.StickerManager?.stickers?.length
      )
      return active ? {text: '•', label: 'Immersion tools are active'} : null
    }

    return null
  }

  Atelier.EssentialsRouter = {
    WORKSPACES,
    loadState,
    getActive,
    navigate,
    viewKey,
    renderView,
    getBadge,
    describeView: workspace => WORKSPACES[workspace]?.label || 'Essentials'
  }
})()
